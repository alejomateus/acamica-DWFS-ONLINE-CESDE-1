//callback funcion que recibe como argumento otra funcion y la ejecuta
//cone le set time out se agrega un retraso a la funcion (tiene un delay) esta se ejecuta despues de un segundo, por ende primero carga la segunda y despues la primera

//se puede ver que el segundo no espero a que se ejecutara el primero para dar respuesta

// let primera = function(){
//     setTimeout(function(){
//         console.log("estoy en primera");
//     }, 1000)
// }

// let segunda = function(){
//     console.log("estoy en segunda");
// }

// primera();
// segunda();

// calback = funcion segunda

//cuando termine la ejecucion de la primera se ejecutara la segunda
//termine la ejecucion de la primera y despues ejecute la segunda

// let primera = function(callback){
//     setTimeout(function(){
//         console.log("estoy en primera");
//     }, 5000)
//     callback(); //==> llama la funcion depues de ejecutar el callback
// }

// let segunda = function(){
//     console.log("estoy en segunda");
// }


// ejecutamos la primera funcion y como parametro la segunda funcion para ejecutarla despues de la primera
// si tuviera la funcion uno mas parametros se colocarian normalmente al lado de callback
//primera(segunda);  //segunda === callback
// segunda();



//////////////////////////////////////////////////////////////////////////////////////////


// funciones in line , en lugar de usar la palabra callback podemos definir la funcion ahi directamente como el setime out que es in line



// let colores = [];

// colores.push("rojo");
// colores.push("azul");
// colores.push("verde");
// colores.push("amarillo");
// console.log(colores);
// colores.sort();
// console.log(colores);

//////////////////////////////////////////////////

// let productos = [];

//le enviamos  objetos al array
// productos.push({nombre: "Remera", precio: 100});
// productos.push({nombre: "Pantalón", precio: 800});
// productos.push({nombre: "Camisa", precio: 300});

// console.log(productos);

//console.log(productos.sort()); //muestra lo mismo porque no ordena los objetos

// como no se pueden ordenar los arreglos con sort creamos una funcion para hacerlo
// productos.sort(function(valor1, valor2){
//     if(valor1.nombre < valor2.nombre){
        //al aldo izquierdo
        //return -1;
    //}else{
        //al lado derecho
        //return 1;
//     }
// });

//en este caso primero se ejecuta y luego

//console.log(productos);

//podemos comparar cadenas de texto cada letra es un numero deacuerdo a la tabla ascii, asi sabemsos si una cadean de texto vale mas que la otra

//let calc =  function (p1, callback){
    // console.log(typeof(callback));
   // if(typeof(callback) !== "function"){
//         throw (new Error ("no es una funcion"));

//     }

//     console.log("hola calc");
//     callback();
// }

// let callc = function() {
//     console.log("hola callback")
// }


// // console.log(calc(2, call));

// try {
//     calc(2, callback);
// }

// catch(e) {
//     console.log(e.name + e.message)
// }


////////////////////////////////////////////////////



// let calc =  function (n, callback){
    // console.log(typeof(callback));
    // if(typeof(callback) !== "function"){
        // throw (new Error ("no es una funcion"));

    //}

    // console.log("hola calc");
//     console.log(callback(n));
    
// }

// let callc = (n) => n*n;


// console.log(calc(2, call));

// try {
//     calc(2, callc);
// }

// catch(e) {
//     console.log(e.name + e.message)
// }



//////////////////////////////////////////////////////////////
// let calc = function(n, callback){
//     console.log(callback)
// }

// calc(2, Math.sqrt);


// let calc = function(n, callback){

// }

// let cback = function(n){
 
// }


// ====================================================================================


//=====================================================================================


// *una funcion callback es una funcion que como parametro recibe otra funcion
    //--declaramos una funcion principal con un parametro llamado callback (es simplemente un parametro);
    //--ejecutamos el callback dentro de la funcion principal


//*declaramos una segunda funcion

//*llamamaos la primera funcion y le enviamos como parametro la segunda funcion


// function main(callback){
//     alert("primero hago algo y despues ejecuto el callback"); 
//     callback();
// }

// function greeting(){
//     alert("yo soy un callback");
// }

// main(greeting);


// ====================================================================================

// EJERCICIO UNO

//=====================================================================================



// Crear una función llamada “calc” que recibe 2 parámetros, el
// primero un número entero el segundo una función que la
// utilizaremos como callback.
// Mostrar los siguientes console.log dentro de cada función:
// ● Hola calc
// ● Hola callback



// function calc(n, callback){
//     console.log("calc" + " " + n);
//     callback();
// }


// function number_two(){
//     console.log("Hola callback");
// }


// calc(2, number_two);



// ====================================================================================

// EJERCICIO DOS

//=====================================================================================


// Crea una nueva función para calcular el cuadrado del
// número entero.
// Calcula el cuadrado del número a través de la función “calc”


// function square_number(n, callback){
//     callback(n);
// }

// function calc(n){
//     console.log(n*n);
// }

// square_number(5, calc);




// ====================================================================================

// EJERCICIO TRES

//=====================================================================================



// Invoca una nueva función a través de un callback que nos
// permita conocer la raíz cuadrada de un número entero.


// function parametro(n, callback){
//     callback(n);
//  }

//  function number(n){
//     console.log(Math.sqrt(n));
// }

// parametro(2, number);

//--------------------------

// function parametro(n, callback){
//     var result = Math.sqrt(n);
//     callback(result);
// }

// function number(result){
//     console.log(result);
// }


// parametro(2, number);



// ====================================================================================

// EJERCICIO CUATRO

//=====================================================================================


// Crea una nueva función para saber si un número
// entero es par o no.
// Utiliza esta nueva función a través de “calc



// function par_number(n, callback){
//     if(n % 2 == 0){
//         callback();
//     }
// }


// function calc(){
//     alert("el numero es par");
// }


// par_number(2, calc);



// ====================================================================================

// EJERCICIO CINCO ===========>preguntar

//=====================================================================================


// Invoca una nueva función a través de un callback que
// nos permita conocer el factorial del número entero


// function factorial (n, callback){
//     if(Number.isInteger(n)){
//         for(i=n; i<n; i--){
//             console.log(i);
//         }
//     }
// }

// function fff(n){
//     if(Number.isInteger(n)){
//         for(i=1; i<n; i++){
//             console.log(n*(i-1));

//         }
//     }
// }
// fff(5);




// ====================================================================================

// EJERCICIO SEIS ====================>preguntar

//=====================================================================================


// Generar una función para trabajar como un array.
// Debe recibir ǽ parámetros, un array y un callback.
// Generar una función para agregar un elemento al inicio del
// array y otra para agregar un elemento al final.
// Generar una función inline que elimine el último elemento.


// var array_numbers = [2, 3, 4];

// function one(array_numbers, callback){
//     console.log(array_numbers);
//     callback(array_numbers);
// }

// function addElement1(array_numbers){
//    array_numbers.push(3)
// }


// one(array_numbers, addElement1);



let suma = (x, y) => {
    return x + y;
}

// declare la funcion suma como variable que recibe los parametros x,y returne la suma de los parametros