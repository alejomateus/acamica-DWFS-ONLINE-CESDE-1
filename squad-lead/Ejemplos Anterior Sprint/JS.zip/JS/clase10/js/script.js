// objetos

// let me  = {
//     nombre: "John",
//     apellido: "osorio"
// }


//Agregando elementos al objeto forma 1
// me.correo = "jhon@jhon.com";
//Agregando elementos al objeto forma 2
// me["edad"] = 30;

// console.log(me);


//Creando clases

// class personas {

// }

//Instanciando una clase

//creando un objeto de esa clase

// yo = new personas {

// };


// let me = {
//     firstname: "juan",
//     lastname: "perez",
//     fullname: function(){
//         return this.firstname + " " + this.lastname
//     }
// }

// console.log(me.fullname());


//Constructores

// class rectangle {
//     constructor(height, width){
//         this.height = height;
//         this.width = width;
//     }

//     //Metodos no van nunca en el constructor, cuando los metodos van en la clase no llevan la palabra function

//     addition (){
//         return this.height + this.width;
//     }
// }


// rectangle1 = new rectangle(10, 20);
// rectangle2 = new rectangle (15, 30);

//llamando el metodo
// console.log(rectangle1.addition());

// console.log(rectangle1.height);
// console.log(rectangle2.height);



// ejercicio clase pasada

// var numbers = [1, 2, 3, 4, 5, 6, 7];
// ccc = typeof numbers;


// function average(n){
//     if(n !== " " && ccc === "object"){
//         for(i=0; i<numbers.length; i++){
//             if(isNaN(numbers[i])){
//                 throw new Error ("no se puede calcular el numero maximo");
//             }
//         }
//     }
    

//     var maxNumber = Math.max(...n);
   
//     console.log(maxNumber);
   
// }

// try{
//     average(numbers);
// }

// catch(e){
//     console.log(e.name + " " + e.message);
// }


// var name = prompt("Ingrese su nombre");
// var last_name = prompt("Ingrese su apellido");
// var email = prompt("Ingrse su email");


// var user = {
//     nombre: name,
//     apellido: last_name,
//     email: email
// }

// alert("El nombre de usuario es " + user.nombre + " " + "El apellido del usuario es " + user.apellido + " " + "El email del usuario es " + user.email);




var name = prompt("Ingrese su nombre");
var last_name = prompt("Ingrese su apellido");
var email = prompt("Ingrse su email");
var age = parseInt(prompt("ingrese su edad"));

class users {
    constructor (name, last_name, email, age){
        this.name = name;
        this.last_name = last_name;
        this.email = email;
        this.age = age;
    }

    
    is_adult(){
        // this.age > 18 ? true : false;
        if(this.age > 18){
          return true;
        }else{
          return false;
        }
    }

    full_name(){
        return this.name + this.last_name;
    }
}

//Nuevo objeto de la clase users
my_info = new users(name, last_name, email, age);
alert("Su nombre es " + my_info.name + " Su apellido es " + my_info.last_name + " Su email es " + my_info.email + " su edad es " + age);

console.log(my_info.full_name());
console.log(my_info.is_adult());

// rrr = [];


// do{
//   var race = prompt("ingrese un raza");
//   var name = prompt("ingrese el nombre");
//   var weight = prompt("ingrese el peso");
//   var age = prompt("Ingrese la edad");

//   class dogs {
//       constructor (race, name, weight, age){
//           this.race = race;
//           this.name = name;
//           this.weight = weight;
//           this.age = age;
//       }
//   }  


//   my_dog = new dogs (race, name, weight, age);
//   rrr.push(my_dog);
//   console.log(my_dog);


// }while(race !== "stop" && name !== "stop" && weight !== "stop" && age !== "stop");
