//funciones


//Nombre del juagador => imput;
//Limitar la cantida de jugadores for i>= 6; si i > muestre alerta
//Rutas: incluya gps o mapas || establecer coordenadas predeterminadas
//combinacionde teclas -- juego del usuario; = > Combinacion de teclas
//Acelerar => barra espaceadora
//parar => flecha hacia atras
//Derecha => fleacha derecha
//Izquierda => flecha izquierda
//Guarde el tiempo para vencer su propio record;
//Muestre el tiempo



//Entrada

//Nombre del jugador
//cantidad de corredores => alerta menor de seis
//Seleccion de auto
//Selecion de pista



//recorrido lista de posiciones





//================================================================================//


//sobrepasos

//Inicio en meta => verifique que los contadores esten en cero
//Muetre la velocidad y las revoluciones desde el inicio a medida que gana o pierde velocidad
//Si un usuario se adelanta, tome el tiempo de diferencia con el auto de atras. 
//si un usuario es adelantado = > envie una alerta de sobrepaso informe el tiempo de diferencia.
//tome el tiempo en la meta del primer usuario que cruza y muestre la diferencia con los otros.
//Tome el tiempo por cada vuelta y muestrelo al usuario.
//tome el tiempo de cada uno de los usurios que van llegando y restelos al tiempo del ganador
  // => para establecer la diferencia de tiempo a la legada.
//Capture los tiempos y muestre los en la clasificacion general .
//seleccione los tres primeros
//coloque los tiempos en el podium.
//Guarde los datos en el perfil del jugador.
//reinicie los contadores.






//========================= pseudocódigo ===================================

//var lado =  input: ingrese el lado del cuadraro
    //perimetro = lado * 4
        //salida = alerta "El perimetro del cuadrado es + perimetro"



        // function perimetro(lado){
        //     return lado * 4;
        // }
        // var result = perimetro(5);
        // alert(result);



//========================= pseudocódigo ===================================

        //var lado_uno = Solicitar lado1
        //var lado_dos = Solicitar lado 2
            //superficie = lado_uno * lado_dos
              //Respuesta = alerta la superficie del rectangulo es + superficie





        // function superficie_rectangulo(lado_uno, lado_dos){
        //     return lado_uno * lado_dos
        // }

        // var area = superficie_rectangulo(3, 5);
        // alert("la superficie del rectangulo es " + area);


        //var lado 1 = Ingrese el lado 1
          //var lado 2 = Ingrese el lado 2 
            //var lado 3 =   ingrse el lado 3

            //si lado 1 = lado 2 = lado 3 
                //alerta El triangulo es equilatero

            //si lado 1 = lado 2 o lado1 = lado 3 o lado 2 = lado 1 o lado 2 = lado 3 o lado 3 = lado 2 o lado 3 = lado 1
                //alerta el trinagulo es isósceles
                
            //si lado 1 es dferente de lado 2 y lado 3
                //alerta  El triangulo es escaleno
                
                



        //  function triangulos(lado_1, lado_2, lado_3){

        //     if(lado_1 === lado_2 && lado_2 === lado_3){
        //         alert("EL TRIANGULO ES EQUILATERO")
        //     }

        //     if(lado_1 === lado_2 || lado_1 === 3 || lado_2 === lado_1 || lado_2 === lado_3 || lado_3 === lado_2 || lado_3 === lado_1){
        //         alert("EL TRIANGULO ES ISOSCELES")
        //     } 

        //     if(lado_1 !== lado_2 && lado_2 !== lado_3 ){
        //         alert("EL TRIANGULO ES ESCALENO")
        //     }
        //  }  
         

        //  triangulos(1,2,3);



     
//========================= pseudocódigo ===================================




//Si se define una variable dentro del if  esta no tendra acciin en el else por eso se puede colocar fuera del if e igualarla a cero y sobreescribirla donde se necesite

// function salario_mensual(valor_hora, nro_horas_trabajadas, horas_extras){
//     var sueldo_sin_extras = 0
//     if(horas_extras === undefined){
//          sueldo_sin_extras = valor_hora * nro_horas_trabajadas;
//         console.log(sueldo_sin_extras);
//         return sueldo_sin_extras;
//     }
//         var valor_extras = ((valor_hora * 50) / 100) * horas_extras + sueldo_sin_extras;
//         return valor_extras;
// }


// var salario_total = salario_mensual (3,3);
// alert("El salario total es " + salario_total);


//========================================================================================

// Solicitar al usuario el valor de su hora, horas
// trabajadas en el mes y horas extras.
// Calcular el sueldo sabiendo que el valor de la
// hora extra es un 50% más que la hora común.


// function sueldo(valor_hora, nro_horas_trabajadas,  horas_extras){

//     var salario_sin_extras =  valor_hora * nro_horas_trabajadas;;

//     if(!horas_extras){
//         alert("El salario sin extras equivale a " + salario_sin_extras);
//     }else{
//         valor_hora_extra = (valor_hora * 50) / 100;
//         salario_con_extras = salario_sin_extras + valor_hora_extra * horas_extras;
//         alert("El salario con extras equivale a " + salario_con_extras);
//     }
// }   

// sueldo(3400,3,2);



// Solicitar al usuario que ingrese infinitos números
// hasta el ingreso de un cero.
// A cada número ingresado calcular su factorial.



// function factorial(number){
//     var result = 0;

//     do{
 
//      for(i=1; i<0; i--){

//         console.log(result = result + i);
//      }
 
 
//     }while( i !== 0)
//  }
 
 
//  factorial(parseInt(prompt("Ingrese un numero")));



// Solicitar al usuario que ingrese infinitos
// números hasta el ingreso de un cero.
// Al finalizar el ciclo mostrar cúal fue el mayor
// número ingresado y también el menor.


var number = [];
var input_number = "";

for(i=1; i<=5; i++){
  if(input_number !== 0){
    input_number = parseInt(prompt("Ingrese un número"));
    number.push(input_number);
  }else{ 
    alert("el numero mayor ingresado es " + Math.max(...number) + " " + "El numero menor ingresado es " + Math.min(...number));
    input_number = parseInt(prompt("Ingrese un número"));
  }
}

alert("el numero mayor ingresado es " + Math.max(...number) + " " + "El numero menor ingresado es " + Math.min(...number));





         
















