// var color = "rojo";

// if(color){
//     console.log("Hola")
// }else{
//     console.log("chau");
// }

// var puede = true;

// if(puede){
//     console.log("hola")
// }else{
//     console.log("chau");
// }

// var puede = false;

//DIFERENTE DE TRUE
// if(!puede){
//     console.log("hola");
// }else{
//     console.log("chau");
// }

// var color = "none";

// if(color){
//     console.log("hola");
// }else{
//     console.log("chau");
// }


// var color = "";

// if(color){
//     console.log("hola");
// }else{
//     console.log("chau");
// }


// var escribe = !true; 

// if(!escribe){ //siempre que sea true muestra hola
//     console.log("hola");
// }else{
//     console.log("chau"); //hola
// }

  

//Ciclo while

// x = 5

// while(x <= 10){
//     x = x+1;
//     console.log("El valor de la variable es " + x);
// }


//do while

// var x = 0;

// do{
//     console.log("El valor de la variable es" + x);
//     x=x+1
// }while(x<=5);


//Solicitando el numero

// var number = prompt("Ingrese un numero");

// while(number <= 100){
//     // si el numero es menor que 100 muestre la alerta
//     alert("Ingrese numeros mayores a 100");
//     // Vuelva a pedir el numero
//     number = prompt("Ingrese un numero");
// }


//ciclo for 

// adition = 0;

// for(i=1; i<=10; i++){
//     number = parseInt(prompt("ingrese un numero"));
//     adition = adition + number;
// }
// answear = adition/10

// alert("el promerdio es " + answear);


///Switch


// var fruits  = prompt("Ingrese su fruta preferida").toLowerCase();

// if(isNaN(fruits)){
//     switch(fruits){
//         case 'naranja':
//             alert("El kilogramo de naranjas vale 700$");
//             break;
        
//         case 'peras':
//             alert("El kilogramo de peras vale 800$");
//             break;
    
//         case 'mandarinas':
//             alert("El kilogramo de mandarinas vale 89$");
//             break;
            
//         default:
//             alert("la fruta " + fruits + " No esta disponible"); 
//     }
    
// }else{
//     alert("No ingrese números");
// }


// addition = 0;

// for (i=1; i<=5; i++){
//     number = parseInt(prompt("Ingrese un número"));
//     addition = addition + number;
//     alert("la suma de lso números ingresados es " + addition);
// }







// do{
//     console.log("El valor de la variable es" + x);
//     x=x+1
// }while(x<=5);

// var number =  prompt("Ingrese un numero");

// var addition = 0
// var number = 0;
// var input;
// var average = 0;

//     do{
//         imput =  prompt("Ingrese un numero");
//         number = imput;
//         if(!isNaN(parseInt(number)) && number < 10){
//             addition = addition + parseInt(number);
//             average = average + 1;
//         }

//     }while(number !== "salir")
//     alert("El promedio es" + (addition/average));




number = parseInt(prompt("Ingrese un numero"));

if(number <= 10 ){
    switch(number){
        case 1:
            alert("1 equivale a a");
            break;
        case 2:
            alert("2 equivale a b"); 
            break;
        case 3:
            alert("3 equivale a c"); 
            break;         
        case 4:
            alert("4 equivale a d"); 
            break; 
        case 5:
            alert("5 equivale a e");
            break;
        case 6:
            alert("6 equivale a f"); 
            break;
        case 7:
            alert("7 equivale a g"); 
            break;         
        case 8:
            alert("8 equivale a h"); 
            break; 
        case 9:
            alert("9 equivale a i"); 
        break;
        case 10:
            alert("8 equivale a j"); 
        break;

         
        default:
            alert("Ingrese numeros de 1 a 10"); 
    }

}



