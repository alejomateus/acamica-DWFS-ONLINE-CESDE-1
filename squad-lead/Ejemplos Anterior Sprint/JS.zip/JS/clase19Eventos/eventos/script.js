var my_btn = document.getElementById("button");

my_btn.addEventListener("mouseup", getting_btn);

function getting_btn(e){
    switch(e.button){
        case 0:
            alert("click ene l boton izquierdo");
            break;
        case 1:
            alert("clicke n el boton del centro");
            break;
        case 2:
            alert("click en el boton derecho");
            break;       
    }
}


// var numbers = document.getElementById("numeros");

// numbers.addEventListener("keyup", getting_number);

// function getting_number (e){
//     console.log(e.key);
//  }

// numbers.addEventListener("keyup", function(e){
//     console.log(e.key)
// });

var text = document.getElementById("mitexto");

var numbers = document.getElementById("numeros");

   numbers.addEventListener("keyup", function(){
     var valor = numbers.value;
     text.innerHTML = valor;
   });


