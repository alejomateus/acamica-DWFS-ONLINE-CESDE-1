
// 1.window.addEventListener("click", ()=>{
//     console.log("dio click");
// });


// window.addEventListener("click", ()=>{
//     console.log("dio click");
// })

// 2.document.getElementById("the_button").addEventListener("click", ()=>{
//      console.log("dio click");
// });





//escuchamos eventos literalment con on mas el nombre del evento
// var the_boton = document.getElementById("the-button");
// console.log(the_boton);

//los eventos on solo se le pueden aplicar una vez al mismo elemento, solo mostraria el ultimo (si se le aplicara 2veces onclick al mismo boton por ejemplo solo se ejecutaria el ultimo onclick el primero se perderia)

//los aventos addeventlistener pueden ser aplicados al mismo elemento tantas veces como se requiera (por ejemplos dos elementos click al m ismo boton )

// the_boton.onclick = () => console.log("dio click en el btn usando onclick 1");
// the_boton.onclick = () => console.log("dio click en el btn usando onclick 2");


// the_boton.onclick = function(){
//     console.log("le dio click1");
// }
// the_boton.onclick = function(){
//     console.log("le dio click2");
// }

// the_boton.addEventListener("click", ()=>{
//     console.log("le dio click1");
// });

// the_boton.addEventListener("click", ()=>{
//     console.log("le dio click2");
// })



















//ojo con onclick solo se puede hacer uno con el mismo boton

// document.getElementById("the_button").addEventListener("click", ()=>{
//     console.log("dio click 1");
// });


// document.getElementById("the_button").addEventListener("click", ()=>{
//     console.log("dio click 2");
// });

//remove event listener


// laf = () => {
//     console.log("EL CALLBACK 1")
//     the_boton.re
// }

// lag = () => {
//     console.log("EL CALLBACK 2")
// }

// the_boton.addEventListener("click", ()=>{
//     laf();
//     the_boton.removeEventListener("click", laf)
// });

// the_boton.addEventListener("click", ()=>{
//     laf();
//     the_boton.removeEventListener("click", laf)
// });


//objeto del evento

// let the_handler = (e) =>{
//     switch(e.button){
//         case 0:
//         case 1:
//         case 2:
//     }
// }

//Propagacion

// const the_button = document.getElementById("the-button");

// window.addEventListener("click", () =>{
//     console.log("dio click en la ventana");
// });

// document.body.addEventListener("click", () =>{
//     console.log("dio click en el body");
// });

// var abuelo = document.getElementById("abuelo");
// var padre = document.getElementById("padre");
// var hijo = document.getElementById("hijo");


// abuelo.addEventListener("click", ()=>{
//     console.log("click en el abuelo");
// });


// padre.addEventListener("click", ()=>{
//     console.log("click en el padre");
// });


// hijo.addEventListener("click", ()=>{
//     console.log("click en el hijo");
// });

//stop propagation

// abuelo.addEventListener("click", ()=>{
//     console.log("click en el abuelo");
// });


// padre.addEventListener("click", (e)=>{
//     console.log("click en el padre");
//     e.stopImmediatePropagation
// });


// hijo.addEventListener("click", ()=>{
//     console.log("click en el hijo");
// });



//event.target

//se refiere al nodo donde se origino el evento


// var abuelo = document.getElementById("abuelo");
// var padre = document.getElementById("padre");
// var hijo = document.getElementById("hijo");
// var body = document.getElementsByTagName("body");

// body.addEventListener("click", (e) =>{
//     console.log(e.target.textContent);
// });

var my_btn = document.getElementById("try");
var stop_btn = document.getElementById("btn_stop");


// window.addEventListener("mousemove", my_function);

// function my_function(){
//     document.getElementById("demo").innerHTML = Math.random();
// }


// my_btn.addEventListener("click", remove_handler);

// function remove_handler(){
//     window.removeEventListener("mousemove", my_function);
// }


// window.addEventListener("mousemove", grow_button);

// function grow_button(e){

//     var width = e.clientX;
//     var height = e.clientY;

//     my_btn.style.width = width + "px";
//     my_btn.style.height = height + "px";
   
// }


// window.addEventListener("click", cancel_growing);

// function cancel_growing(){  
//     window.removeEventListener("mousemove", grow_button);
// }





// document.addEventListener("mousemove", (e)=>{
   
//     var alto = e.clientY;
//     var ancho = e.clientX;

//     my_btn.style.height = alto + "px";
//     my_btn.style.width = ancho + "px";

// });







// ​
// let the_handler = (e) => {
//     switch(e.button) {
//         case 0:
//             console.log("Presiono el izquierdo");
//             break;
//         case 1:
//             console.log("Presiono el del medio");
//             break;
//         case 2:
//             console.log("Presiono el derecho");
//             break;
//         default:
//             console.log("Presiono otro");
//     }
// }

// my_btn.addEventListener("mouseup", check_button);

// function check_button(e){
//     console.log(e.button);
//     switch(e.button) {
//         case 0:
//             console.log("Presiono el izquierdo");
//             break;
//         case 1:
//             console.log("Presiono el del medio");
//             break;
//         case 2:
//             console.log("Presiono el derecho");
//             break;
//         default:
//             console.log("Presiono otro");  
//     }
// }

// stop_btn.addEventListener("click", stop_cases);

// function stop_cases(){
//     my_btn.removeEventListener("mouseup", check_button);
// }




// function check_button(e){

//     switch(e.button){
//         // case 0:
//         //     console.log("presionó el boton izquierdo");
//         //     break;
//         case 1:
//             console.log("prsionó el botón del centro");
//             break;
//         case 2:
//             console.log("presiono el boton derecho");
//             break; 
//         default:
//             console.log("Presiono otro");    
//     }
// }


var divOne = document.getElementById("div1");
var divTwo = document.getElementById("div2");


divOne.addEventListener("click", ()=>{
    alert("se clique el div 1");
    
});

divTwo.addEventListener("click", (e)=>{
    alert("se clique el div 2");
    e.stopPropagation();
});








