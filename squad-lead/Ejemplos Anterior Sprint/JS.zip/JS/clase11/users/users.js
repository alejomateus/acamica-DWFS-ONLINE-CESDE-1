// import {users}  from '../variables.js';
console.log(users);


function registerUser(event) {
   const newUser = {
      firstName: document.getElementById('firstName').value,
      lastName: document.getElementById('lastName').value,
      email: document.getElementById('email').value,
      phone: document.getElementById('phone').value
   };
   event.preventDefault();
   
   users.push(newUser);
   loadUsers();
   console.log(users);
}

var list = document.getElementById('users');

function loadUsers() {
   users.forEach(function(user) {
      const newUserItem = document.createElement('li');
      const newText = document.createTextNode(
         `${user.firstName} ${user.lastName} ${user.phone} ${user.email}`
         );
         newUserItem.appendChild(newText);
         newUserItem.className = 'list-item';
         list.insertBefore(newUserItem, list.lastElementChild);
      });
   }
   document.getElementById('submit').addEventListener('click', registerUser);
   window.addEventListener('load', loadUsers);


   
   
   