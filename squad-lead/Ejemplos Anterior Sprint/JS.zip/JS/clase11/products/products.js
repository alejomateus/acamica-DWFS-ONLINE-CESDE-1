const products = [];

document.getElementById('submit').addEventListener('click', onSubimtProduct);
window.addEventListener('load', loadProducts);

function onSubimtProduct(event) {
   const newProduct = {
      name: document.getElementById('name').value,
      desc: document.getElementById('desc').value,
      price: document.getElementById('price').value,
      quantity: document.getElementById('quantity').value
   };

   products.push(newProduct);
   loadProducts();
   event.preventDefault();
}

const list = document.getElementById('products');

function loadProducts() {
   products.forEach(function(product) {
      const newProductItem = document.createElement('li');
      newProductItem.className = 'list-item';
      const newText = document.createTextNode(
         `We have ${product.quantity} ${product.name}s for ${product.price}. We are confident this is ${product.desc}`
      );
      newProductItem.appendChild(newText);
      list.insertBefore(newProductItem, list.lastElementChild);
   });
}
