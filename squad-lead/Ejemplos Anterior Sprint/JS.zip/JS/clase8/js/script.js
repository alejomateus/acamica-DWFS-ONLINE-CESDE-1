// var = puede cambiar valor y su escope es local
// let = puede cambiar valor solo vivira en el bloque donde fue creada
// cons = no cambia 


//var x //Declarando la variable

//x = 5 inicializando la variable 

// var x;

// console.log(x);


//Por el hoisting se puede ejecutar la funcion antes de crearla


// hello_world();
// var msg = "acamica"; // aparecera undefined porque esta ejecutando primero la funcion y despeus la variable


// function hello_world(){
//     console.log(msg)
// }

//El concepto de hoisting solo funciona para variables let , es comos si reorganizara todo
// diferencia entre una funcion en una variable o una funcion normal  ==> importante




// EXEPCIONES

// Evento que ocurre al ejecutar el codigo, por ejemplo recibo numeros y alguien pone cero

// try {
//     myFunction();
// }

// catch(e) {

// }


// function myFunction(){
//     console.log("Hola Acamica");
//     var x =  5 / 0;
    
//     return w
// }



// try {
//     myFunction();
// }

// catch(e) {
//     console.log("Hubo un error con name " + e.name + " y mensaje " + e.message);
// }



// const user = "john";
// const password = "123456";


// var name = prompt("Ingrese su nombre");
// var password2 = prompt("Ingrese su contraseña");

//Los nombres de los parametros pueden ser cualquiera
//Ya que el valor de los mismos se asignan al ejecutar la función

// function my_session(user_name, user_password){
    
//     if(user_name === "john" && user_password === "123456"){
//         alert("Ingreso exitosamente");
//     }
//     else{
//         alert("Ingrese usuario y contraseña validos");
//     }
// }

// my_session(name, password2);


//=================================================================================

// var radio = parseInt(prompt("Ingrese el valor del radio"));

// function diameter(circle_radio){

    // excepcion 1
//     if(isNaN (circle_radio)){
//         throw new Error ("Invalid radio number");
//     }
    
//     alert("el diametro del circulo es " + 2*circle_radio)
// }


// try {
//     diameter(radio);
// }

// catch(e){
//     alert("Ingese un valor valido " + e);
//     console.log(e.name + "/" + e.message); //e.name error // if.message  = "" {}
//     //e.message es el mensaje lanzado invalid radio number
// }




// diameter(radio);



//=================================================================================



//la funcion siempre va por fuera del try y el catch

// function integer_number(name_one, name_two){

    //Primera exepcion, sis e ingresan cadenas de texto manda a el catch automaticamente , osea si no se cumple la condicion
//     if(isNaN(name_one) || isNaN(name_two)){
//         throw new Error ("Ingrese numeros validos");
//     }


//     if(Number.isInteger(name_one) && Number.isInteger(name_two)){
//         result = (name_one + name_two);
//         return result;
        
//     }else{
//         alert("Los numeros no son enteros");
//     }
// }


//en el try definimos los parametros pde la fucnion y hacemos el llamado, ahi van las condiciones los ciclos etc etc
//Try catch van siempre pro fuera de la funcion

// try {

//     do{
//         n1 = parseFloat(prompt("Ingrese un número"));
//         n2 = parseFloat(prompt("Ingrese otro número"));

//         integer_number(n1, n2);
        
//     }while(
//         result < 100
//     )
    
// }

// catch(e){
//     console.log(e.name + " " + e.message); //e.name = error, e.message = ingrse numeros validos linea 130
// }



//=================================================================================


// function show_letter(){
//     var number = parseInt(prompt("Ingrese un número"));

//     if(isNaN(number)){
//         throw new Error ("No ingrese cadenas de texto");
//     }

//     console.log("El primer numero es " + number);
    

//     if(number > 10){
//         var number = parseInt(prompt("Ingrese un número"));
//         if(number > 100){
//             alert("A")
//         }else{
//             alert("B")
//         }
//     }else{
//         var number = parseInt(prompt("Ingrese un número"));
//         if(number > 100){
//             alert("C");
//         }else{
//             alert("D");
//         }
//     }
    
// }

// try{
//     show_letter();
// }

// catch(e){
//     alert(e.name + " " + e.message);
// }



