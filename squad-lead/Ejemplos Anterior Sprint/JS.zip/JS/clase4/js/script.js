//Funciones nativas del navegador


//propt pedir info al usuario siempre arroja cadenas de texto 
//Alert muestra un mensaje
//console.log() imprimir en la consola

// prompt("Por favor ingrese su nombre");

//La funcion typeof() nos indica que tipo de valor tiene una variable

// console.log(typeof(3)); //number
// console.log(typeof("hola mundo")); //string

//sintaxis 2
// console.log(typeof "Hola mundo2");

//Recibe un valor tipo string y lo convierte en un number
//Solo sirve para numeros sin decimales
// console.log(parseInt("3"));

//Si un numero llega como cadena de texto y es flotante osea tiene decimales

// console.log(parseFloat("3.1416"));


//Si le paso una cadena de texto a la funcion es imposible para parse int sacar un numero de un string
// console.log(parseInt("tres")); //Debuelve nan not a number


// BUSCAR

isNaN(parseInt);

//Identifica cual es numero  y quita el resto. solo cuando inicia con numero
// console.log(parseInt("345Seis"));

// console.log(3/0); //da infinity


// console.log((3/0).toString()); //da infinity per como string







//TRANSFORMACION DE TEXTOS

var XX = "TTTTTTT";
var YY = "zzzzzzzzzzzzzz";

// console.log(XX.toLowerCase())  //convierte el string a minusculas
// console.log(YY.toUpperCase());  //Convirtiendo string a Mayuscula


//Concatenando strings 

// console.log("hola " + prompt("ingrse su nombre"));

//Si concatenamos un string + un numero debolveria un string 33 

// console.log("3" + 3);


//Expresiones todos son expresiones



// alert(3 + 4/2);
// alert ((3+4)/2);





/*=======================================================
Convestir una suma de enteros a un string
==========================================================*/



// console.log((3+4).toString());





/*=======================================================
Concatenacion
==========================================================*/


//Primero ejecuta la funcion promp y despues lo concatena a la cadena 

// alert("su nombre es " + prompt("Ingrese su nombre"));


// alert("su nombre es" + prompt("Digite su nombre").toUpperCase());


//Primero tomara el numero, lo convertira en string y lo mostrara en la consola

// console.log(parseInt(prompt("Ingrese un numero")));


//Tomamos dos numeros y los sumamos

// var1 = parseInt(prompt("Ingrese el primer numero"));

// var2 = parseInt(prompt("Ingrese el segundo numero"));


// alert("el resultado es" + (var1 + var2));



/*=======================================================
Obteniendo un promedio
==========================================================*/


// var one = 1;
// var two = 2;
// var three = 3;
// var four = 4;
// var five = 5;


// alert("El promedio es" + (parseFloat((one + two + three + four + five) /5)));


/*=======================================================
Perimetro de un circulo
==========================================================*/


//perimetro de un circulo 

// 2pir

// var pi = 3.1416;
// r = prompt("Ingrese el valor del radio;");

// alert("El perimetro del circulo es " + parseFloat(2*pi*r));


/*=======================================================
Superficie de un circulo
==========================================================*/


//Superficie del circulo

// var d = parseFloat(prompt("Ingrese el valor del diametro"));

// var pi = 3.1416;

// alert("ls superficie del circulo es " + (2*pi*d));




/*=======================================================
Mostrar nombre en minusculas toLowerCase
==========================================================*/


// var name = prompt("Por favor ingrese su nombre");

// alert("Su nombre es " + name.toLowerCase());



/*=======================================================
Mostrar Apellido en mayusculas toUppercase
==========================================================*/

// var lastname = prompt("Por favor ingrese su apellido");

// alert("Su apellido es " + lastname.toUpperCase());





/*=======================================================
Mostrar nombre y apellido toLowerCase toUpperCase
==========================================================*/

// var name_two = prompt("Ingrese su nombre").toLowerCase();
// var lastname_two = prompt("Ingrese su apellido").toUpperCase();

// alert("nombre: " + name_two + "\n" + "su apellido es: " + lastname_two);




/*=======================================================
Mostrar nombre apellido y edad  Concatenacion parseint => de
cadena de texto a  numero
==========================================================*/


var name_three = prompt("Por favor ingrese su nombre");
var lastname_three = prompt("Por favor ingrese su apellido");
var age = parseInt(prompt("Por favor ingrese su edad"));


alert("Sus datos son: " + "\n" +  "\n" + "Nombre: " + name_three + "\n" + "Apellido: " + lastname_three + "\n" + "Edad: " + age);














