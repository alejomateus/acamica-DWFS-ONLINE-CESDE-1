// declaramos una funcion asyncrona con asign sabemos que va a ddevolver una promesa
// async function getUserFromGithub(userName){
//     console.log("empezó");

//     let url = 'http://api.github.com/user/'+userName;

//     los metodos que esperan la carga de la info les colocamos await

//     si no colocamos await no espera
//    const resp = await fetch(url);

//     const datos = await resp.json(); //

//      si no colocamos await no espera, va a mostrar la respuesta 
//      de una pero como no alcanza a cargarse la url pues muestra error
//     console.log(datos);

//     console.log("termino");

//     return datos;
// }

// datos = getUserFromGithub("frenchita");

// retorna una promesa
// console.log(datos);

// una funcion asign await retorna una promesa
// Resolvemos la promesa
// datos

//     .then((res)=>{
//         console.log(res);
//     });



///////////////Ejemplo 2


// async function getUserFromGithub(userName) {
//     let url = 'http://api.github.com/user/'+userName;
//     const resp = await fetch(url);
//     const datos = await resp.json();
//     return datos;
// }
// datos = getUserFromGithub('frenchita');
// datos.then((resolve)=>{
//     console.log(resolve);
// });



/*==================================================================================== 

EJERCICIO UNO

Sobre siguiente endpoint
https://jsonplaceholder.typicode.com/users
Generar una promesa que muestre los nombres de usuario
una vez que la llamada al endpoint este completa

=================================================================================*/


// FETCH DEBUELVE UNA PROMESA
// JSON RETORNA PROMESA

//Fetch trae información mediante una url, fetch crea una promesa promete traer algo 
//declaramos la solucion de la promesa un then, transformamos  la la informacion que ahora esta contenida en el parametro response
//declaramso otro then y lo mostramos en consola

function user(url){
    fetch(url)
    .then(response => response.json())//.jason convierte a un objeto de javascript la info de la url
    .then(res => {
        console.log(res);
    }).catch(error => {
        console.log(error);
    });
}


user("http://jsonplaceholder.typicode.com/users");



///////===============================Ejercicio Dos


// async function get_name (name){

//     let url = "http://jsonplaceholder.typicode.com/users" + name;

//     const g_name = await fetch(url);

//     const full_name = await g_name.json();

//     return(full_name);
// }

// let my_name = get_name("mario");


// console.log(my_name);

// my_name
//     .then(function(res){
//         console.log(res);
//     }).catch(function(error){
//         console.log(error);
//     });





// async function name(user_name) {

//     let url "https://api.github.com/users/"

// }



