// ===========================================
//EJERCICIO 1 
//=============================================

var my_heading = document.querySelector("#my_heading");
my_heading.innerText = "New Heading";

// ===========================================
//EJERCICIO 2
//=============================================

var menu = document.querySelector("#navigation_menu").firstElementChild;
var new_element = document.createElement("li");
new_element.innerHTML = "<a>new option</a>";
menu.after(new_element);

// ===========================================
//EJERCICIO 3
//=============================================
var image_route = document.querySelector("#changing_img");

function loading_pic(){
    setTimeout(()=>{
        image_route.src = "img/change.png";
    }, 2000);
}


loading_pic();

// ===========================================
//EJERCICIO 4
//=============================================}

/*******************************************************/


var car_one = document.getElementById("car1");
var car_two = document.getElementById("car2");

var car_one_description = document.getElementById("car1_description");
var car_two_description = document.getElementById("car2_description");



async function get_users(user_name_one, user_name_two){
    
    let user_one = await fetch("https://api.github.com/users/" + user_name_one);
    let user_two = await fetch("https://api.github.com/users/" + user_name_two);

    let info_one = await user_one.json();
    let info_two = await user_two.json();

    //*************perfil uno

    if(info_one.message === "Not Found"){
        car_one.src = "img/mercedes3.png";
        car_one_description.innerHTML = "Lorem, ipsum dolor."
    }else{
        car_one.src = info_one.avatar_url;
        car_one_description.innerHTML = info_one.login;
    }

    //*************perfil dos

    if(info_two.message === "Not Found"){
        car_two.src = "img/mercedes4.png";
        car_two_description.innerHTML = "Lorem, ipsum dolor.";
    }else{
        car_two.src =  info_two.avatar_url;
        car_two_description.innerHTML = info_two.login;
    }
}


get_users("john", "david");
