//Vamos a cambiar una imagen de un html, mediante el uso de cabeceras (es un ejercico de practica si no colocamos cabecera no pasa nada ya que por defectoe s get) 

// 1.en la variable cabecera declaramos el objeto para crear cabecera
//creamos la variable opciones que es un objeto ahi colocaremos toda la información de consulta para traer la imagen
  //* Especificamos:
  //method:
  //headers:
  //mode:
  //cache:
  //haeders

//3. declaramos la funcion new_img com parametro url  
//4. ustize fecth que debuelve una promesa
//5resulva la promesa use el parametro res
//6. si la respuesta es positiva encontró la imagen
//7. en la variable imagen guarde el elemento con id changing_img
//8. cambiele al atributo src existente por el nuevo
//9. si la respuesta es negativa muestre en un console no se encontró

var cabecera = new Headers();

var opciones = {
    method: "Get",
    headers: cabecera,
    mode: "cors",
    cache: "default",
    haeders: {
        "content-type": "img/jpeg" 
    }
}

function change(url){
    fetch(url, opciones)
    .then((res)=>{
        if(res.ok){
            var imagen = document.getElementById("changing_img");
            imagen.src = res.url;
        }else{
            console.log("no se encontró la imagen");
        }
    })
}


change("img/change.png");