var user_name = document.getElementById("user_name");
var password = document.getElementById("password");
var btn_submit = document.getElementById("btn_submit");

//Form 2 info users

var info_name = document.getElementById("name");
var info_last_name = document.getElementById("last_name");
var info_dni = document.getElementById("dni");
var info_birthday = document.getElementById("birthday");
var info_hobbies = document.getElementById("hobbies");
var info_button = document.getElementById("button2");

btn_submit.addEventListener("click", ()=>{
    user_name_value = user_name.value;
    password_value = password.value;

    if(user_name_value !== "" && password_value){
        localStorage.setItem("userName", user_name_value);
        localStorage.setItem("userPassword", password_value);

        var recovering_userName = localStorage.getItem("userName");
        var recovering_userPassword = localStorage.getItem("userPassword");
        
        //Si hay info en el local storage es porque ya se inicio sesion
        if(recovering_userName && recovering_userPassword){ 
            //esconda el form
            document.getElementById("login_form").style.display = "none";
            //cree un elemento div
            var alert = document.createElement("a");
            //meta una alerat que diga cerrar sesion
            alert.innerHTML = "Cerrar sesion";
            alert.setAttribute("href", "index.html");
            //agreguela al documento
            document.body.appendChild(alert);
            //si le doy click a cerrar sesion
            alert.addEventListener("click", function(){
                //elimine lo que hay en el local storage
                localStorage.removeItem("userName");
                localStorage.removeItem("userPassword");
                //recargue la página
                //location.reload();
            });

            //muestre el otro form, obtenga toda la info en local storage, luego coloquelos como value
            var from_after_login = document.getElementById("from_after_login");
            from_after_login.style.display = "block";

            info_button.addEventListener("click", ()=>{

                info_name_value = info_name.value;
                info_last_name_value = info_last_name.value;
                info_dni_value = info_dni.value;
                info_birthday_value = info_birthday.value;
                info_hobbies_value = info_hobbies.value;

                if(info_name_value !== "" && info_last_name_value !== "" && info_dni_value !== "" && info_birthday_value !== "" && info_hobbies_value !== ""){

                    var user_information = {
                        name: info_name_value,
                        last_name: info_last_name_value,
                        dni: info_dni_value,
                        birthday: info_birthday_value,
                        hobbies: info_hobbies_value
                    }

                    console.log(user_information);



                    //convirtiendo a json
                    var user_info_json = JSON.stringify(user_information);
                    
                    //guardando el json en local storage
                    var user_info = localStorage.setItem("user_info", user_info_json);

                    //trayendo la info del json del local storage
                    var recovering_user_info = localStorage.getItem("user_info");

                    if(recovering_user_info){
                        //convirtiendo el json a objeto de js
                        var user_info_js = JSON.parse(recovering_user_info);
                        //guardando cada una de los items del objeto en variables
                        var new_name = user_info_js.name;
                        var new_last_name = user_info_js.last_name;
                        var new_dni = user_info_js.dni;
                        var new_birthday =  user_info_js.birthday;
                        var new_hobbies = user_info_js.hobbies;

                        //enviando las variables a local storage

                        localStorage.setItem("new_name", new_name);
                        localStorage.setItem("new_last_name", new_last_name);
                        localStorage.setItem("new_dni", new_dni);
                        localStorage.setItem("new_birthday", new_birthday);
                        localStorage.setItem("new_hobbies", new_hobbies);
                    
                    }

                }else{
                    console.log("los campos estan vacios");
                }
            
            });


            
            info_name.value = localStorage.getItem("new_name");
            info_last_name.value = localStorage.getItem("new_last_name");
            info_dni.value = localStorage.getItem("new_dni");
            info_birthday.value = localStorage.getItem("new_birthday");
            info_hobbies.value = localStorage.getItem("new_hobbies");
        }
    }
});



