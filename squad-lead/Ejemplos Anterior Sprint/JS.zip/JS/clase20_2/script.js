var news_quantity = document.getElementById("quantity");
var searhing_button = document.getElementById("searching_btn");

searhing_button.addEventListener("click", ()=>{
    //seleccionamos el contenedor  donde vamos a meter todo
    //verificamos que este vacio
    var new_news = document.getElementById("news");
    new_news.innerHTML = "";
    
    var news_quantity_val = news_quantity.value;
    if(news_quantity_val !== ""){
        
        async function chuck(url){
            var getting_phrases = await fetch(url);
            var json_transform = await getting_phrases.json();

            var new_element = document.createElement("div");
            new_element.classList.add("news", "d-flex", "justify-content-around", "align-items-center", "mt-5", "rounded", "p-2", "shadow-sm", "mb-5"); 
            new_element.innerHTML = `<div data-toggle="modal" data-target="#exampleModal"><img src="chuck-norris-logo.png" alt=""></div>
            <p class="m-0">id: ${json_transform.id}</p>`
            
            new_news.appendChild(new_element);    
        }

       
        
        for(i=0; i<news_quantity_val; i++){
            chuck("https://api.chucknorris.io/jokes/random");
        } 
     
    } 

});





