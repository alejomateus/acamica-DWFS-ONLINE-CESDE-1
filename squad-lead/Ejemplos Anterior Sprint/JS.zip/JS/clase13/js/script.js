//promise es una clase
//instanciamos la clase promise
//Resolve y reject son 2 funciones
//si es exitosa llama a la funcion resolve
//si el resultado de la promesa no es exitosa llamos a reject 


//===================================================================

// Ejemplo 1

//===================================================================

// let promesa = new Promise (resolve, reject) {}
//resolve y reject pueden contener cuallquier cosa funciones arrays, se le da valor a estos parametros 
//cuando se llame  la promesa, en este caso recibio una cadena de texto

// let promesa = new Promise(function(resolve, reject){
//     if(true){
//         resolve("La promesa finalizo correctamente")
//     }else{
//         reject("ha ocurrido un error")
//     }

// });

//===================================================================

// Ejemplo 2 ssi la promesa se resolvio correctamente

//===================================================================

//true o false de parametro

// let promesa = new Promise(function(resolve, reject){
//     if(true){//le pude haber puesto un array [1,2,3]
//         resolve("la promesa finalizó correctamente");
//     }else{
//         reject("Ha occurrido un error");
//     }
// });

// al metodo then le pasamos la funcion response para que se ejecute
//then = cuando la promesa cambia a resolve ejecuta la funcion response
// response = la promesa finalizó correctamente


// promesa.then(function(response){
//     console.log("respuesta:" + response);
// });

// Si la promesa falla

// promesa.catch(function(error){
//   console.log("respuesta: " + error)
// });



//===================================================================

// Ejemplo 3 sintaxis ecncadenando try an catch

//===================================================================



//true o false de parametro

// let promesa = new Promise(function(resolve, reject){
//     if(true){//le pude haber puesto un array [1,2,3]
//         resolve("la promesa finalizó correctamente");
//     }else{
//         reject("Ha occurrido un error");
//     }
// });


// promesa
//el parametro response del then siempre va a traer lo que le escpecifique si se ejecuta la promesa correctamente
    // .then(function (response){
    //     console.log("respuesta: " + response);
    // })

    // .catch(function(error){
    //     console.log("Error: " + error);
    // });





    
//===================================================================

//estado pendiente

//===================================================================



//true o false de parametro

// let promesa = new Promise(function(resolve, reject){
//     console.log("pendiente.....");

    //La función esperará dos segundos antes de ejecutarse, mientras tanto estara en estado pendiente como lo mueestar el console
    // setTimeout(function(){
        //if(true){//le pude haber puesto un array [1,2,3]
            //resolve("la promesa finalizó correctamente"); //esto se lo envio como parametro a response, pero lo puedo llamar como quiera
        // }else{
            // reject("Ha occurrido un error");
//         }
//     },2000)
// });


// promesa
//el parametro response del then siempre va a traer lo que le escpecifique si se ejecuta la promesa correctamente
    // .then(function(response){
        //console.log(promesa); //verifica ele stado de la promesa
    //     console.log("respuesta: " + response);
    // })

    // .catch(function(error){
    //     console.log("Error: " + error);
    // });


//===================================================================

// Promise.all Resolve

//===================================================================

// promise es una clase
//.all es un metodo estatico (que no se instancia no se pone new) no se instancia la clase promise 

// si tengo varias promesas puedo ejecutarlas una por una con then y catch o cuando todas sean resueltas
// con resolve si alguna de las promesas es reject manda el mensaje del catch

// let promesa1 = new Promise((resolve, reject) =>{
//     resolve("uno");
// });

// let promesa2 = new Promise((resolve, reject) =>{
//     reject("dos");
// });

// let promesa3 = new Promise((resolve, reject) =>{
//     resolve("tres");
// });

// Promise.all([promesa1, promesa2, promesa3]).then(function(respuesta){
//     console.log(respuesta); //imprime un array con todos los result
// }).catch(function(error){
//     console.log("Error: " + error);
// });

// var nombre = "john";
// var apellido = "osorio"; 
// var edad = 20;

// let promesa1 = new Promise((resolve, reject)=>{
//     if(nombre === "john"){
//         resolve("su nombre es john");
//     }else{
//         reject("su nombre no es john");
//     }
// });


// let promesa2 = new Promise((resolve, reject)=>{
//     if(apellido === "osorio"){
//         resolve("su apellido es osorio");
//     }else{
//         reject("su apellido no es osorio")
//     }
// });

// let promesa3 = new Promise((resolve, reject)=>{
//     if(edad === 20){
//         resolve("su edad es 20 años");
//     }else{
//         reject("su edad no es 20 años");
//     }
// });

// Promise.all([promesa1, promesa2, promesa3]).then(function(res){
//   alert("Respuesta: " + res);
// })
// .catch(function(error){
//   alert("Respuesta: " + error);
// });






//===================================================================

// Promise.all Reject

//===================================================================

// promise es una clase
//.all es un metodo estatico (que no se instancia no se pone new) no se instancia la clase promise 

// si tengo varias promesas puedo ejecutarlas una por una con then y catch o cuando todas sean resueltas
// con resolve si alguna de las promesas es reject manda el mensaje del catch

//Cuado usamos reject toma siempre el primer reject

// let promesa1 = new Promise((resolve, reject) =>{
//     console.log(promesa1);
//     reject("uno");
    
// });

// let promesa2 = new Promise((resolve, reject) =>{
//     console.log(promesa2);
//     reject("dos");
// });

// let promesa3 = new Promise((resolve, reject) =>{
//     console.log(promesa3);
//     reject("tres");
// });

// Promise.all([promesa1, promesa2, promesa3]).then(function(respuesta){
//     console.log(respuesta); //imprime un array con todos los result
// }).catch(function(error){
//     console.log("Error: " + error);
// });

//caso de uso necesito usuario y productos para hacer pedido
//necesita saber si las dos promesas traen datos
//si no haga llamado otra vez




//===================================================================

// Promise.race captura la primera que resuleva o la primera que falla

//===================================================================


// let promesa1 = new Promise((resolve, reject) =>{
//     setTimeout(function(){resolve("uno")}, 500);
// });


// let promesa2 = new Promise((resolve, reject) =>{
//     setTimeout(function(){resolve("dos")}, 300);
// });

// let promesa3 = new Promise((resolve, reject) =>{
//     setTimeout(function(){resolve("dos")}, 1000);
// });


// Promise.race([promesa1, promesa2, promesa3]).then(function(res){
//     alert("respuesta " + res)
// })
// .catch(function(error){
//     alert("error: " + error);
// });



//===================================================================

// Encadenamientod de promises (cuando tenemos muchas promises)
//Cadenan de promesas;

//===================================================================

//cuando se resulva una promesa llame la otra

let promesa1 = new Promise((resolve, reject) => {
    resolve("uno");
});

let promesa2 = new Promise((resolve, reject) => {
    resolve("dos");
});

let promesa3 = new Promise((resolve, reject) => {
    resolve("tres");
});

promesa1.then(
    function(respuesta){
        console.log(respuesta);
        return promesa2
    }).then(function(segunda){
        console.log(segunda);
        return promesa3
    }).then(function(tercera){
        console.log(tercera);
    }).catch(function(error){
        // captura cualquier error
        console.log("Error: " + error)
    });   
    

//Ejercicio 1


// let promesa = new Promise(function(resolve, reject){
//     setTimeout(function(){
//         if(true){
//            reject ("se rechazo") 
//         }
//     }, 2000)
// });

// promesa
//     .then(function(response){
//         console.log(promesa); 
//         console.log("respuesta: " + response);
//     })
//     .catch(function(error){
//         console.log(promesa);
//         console.log("Error: " + error);
//     });

 
//Ejercicio 3

// var par = (number) => number % 2 == 0; //para hacerlo con terniario


// let promesa = new Promise(function(resolve, reject){
//     var ttt = parseInt(Math.random() * 101);

//     par(ttt) ?  resolve({mensaje: "Exito", valor: ttt}) : reject({mensaje: "Error", valor: ttt});
    // if(ttt % 2 == 0){
    //     resolve({mensaje: "Exito", valor: ttt})
    // }else{
    //     reject({mensaje: "Error", valor: ttt});
    // }
// });


//ene ste ejercicio el then y el catch no aceptaron si no un parametro por eso usamos un objeto
// promesa
//     .then(function(response){
//         console.log(`Mensaje: ${response.mensaje}, Valor: ${response.valor}`)
        //console.log(promesa);
        //console.log("respuesta " + promesa)
    // })

    // .catch(function(response, ttt){
    //     console.log(`Mensaje: ${response.mensaje}, Valor: ${response.valor}`)
        /*console.log(ttt);
        console.log(promesa);
        console.log(error);*/
    // });



    //ejercicio 



//     function getRndInteger(min, max) {
//         return Math.floor(Math.random() * (max - min + 1) ) + min;
//       }

//     var random1 = getRndInteger(0, 1000);
//     var random2 = getRndInteger(0, 1000);

//     console.log(random1);
//     console.log(random2);


//     let promesa1 = new Promise (function(resolve, reject){
//         setTimeout(function(){
//             resolve("primera funcion")
            
//         }, random1);
//     });

//     let promesa2 = new Promise (function(resolve, reject){
//          setTimeout(function(){
//             resolve("segunda funcion");
//          }, random2);
//     });


// Promise.race([promesa1, promesa2]).then(function(answear){
//     console.log(answear);
// });





    //ejercicio 4

    // var number = parseInt(prompt("ingrese un numero"));

    // let promesa1 = new Promise((resolve, reject, number) => {

    // }
    
    // let promesa2 = new Promise((resolve, reject, number) => {

    // }

    // let promesa3 = new Promise((resolve)
    
    // let promesa3


    // let promesa1 = new Promise((resolve, reject) => {
//     resolve("uno");
// });

// let x = 10;

// const p = new Promise ((resolve, reject)=>{
//     if(x == 10){
//         resolve("x es igual a 10");
//     }else{
//         reject("x es diferente de 10");
//     }
// });


// p
// .then((res)=>{
//     console.log("respuesta" + res)
// });

// p
// .catch((error)=>{
//     console.log("respuesta" + error);
// });



