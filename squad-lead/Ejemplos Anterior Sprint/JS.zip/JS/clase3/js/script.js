var trm = document.querySelector("#trm");
    amount = document.querySelector("#amount");
    select_exchange = document.querySelector("#select-exchange");
    exchage_to = document.querySelector("#exchange-to");
    btn_convert = document.querySelector("#btn-convert");
    alert = document.querySelector(".alert");
    alert_two = document.querySelector(".alert-two");
    alert_three = document.querySelector(".alert-three")
    answear = document.querySelector("#answear");



select_exchange.addEventListener("change", function(){
    var select_exchange_value = select_exchange.value;
    if(select_exchange_value == "cop"){
        exchage_to.innerHTML = "Usd";
    }
    if(select_exchange_value == "usd"){
        exchage_to.innerHTML = "Cop";
    }
});


btn_convert.addEventListener("click", function(){
    var trm_value = trm.value;
        amount_value = amount.value;
        select_exchange_value = select_exchange.value;

    
    //*******************  Alerts

 
    //Obligatorios
    if(trm_value == "" || amount_value == ""){
        alert.style.display = "block";
    }else{
        alert.style.display = "none";
    }
    
    //Superiores a cero
    if(trm_value <= 0 && trm_value != "" || amount_value <= 0 && amount_value != ""){
        alert_two.style.display = "block";
    }else{
        alert_two.style.display = "none";
    }


    //Valores no pueden ser iguales
    if(trm_value === amount_value && trm_value != 0 && amount_value != 0 && trm_value > 0 && amount_value > 0){
        alert_three.style.display = "block";
    }else{
        alert_three.style.display = "none"; 
    }

    //*********************
    


    if(select_exchange_value == "usd" &&  trm_value != "" && trm_value > 0 && amount_value != "" && amount_value > 0 && trm_value != amount_value){
        var actual_currency = amount_value*trm_value;
        answear.style.display = "block";
        answear.innerHTML = "<h4>"+amount_value+" "+"Usd" +" "+"equivalen"+" "+"a"+" "+actual_currency+" "+"Cop"+"</h4>";
    }else {
        answear.style.display = "none";
    }

    if(select_exchange_value == "cop" &&  trm_value != "" && trm_value > 0 && amount_value != "" && amount_value > 0 && trm_value != amount_value){
        var actual_currency = amount_value/trm_value;
        answear.style.display = "block";
        answear.innerHTML = "<h4>"+amount_value+" "+"Cop" +" "+"equivalen"+" "+"a"+" "+actual_currency+" "+"Usd"+"</h4>";
    }
});











