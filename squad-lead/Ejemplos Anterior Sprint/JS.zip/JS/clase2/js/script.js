//let container = document.getElementById("container");

//container.innerHTML = "Acamica 2020";

//Los objetos tienen atributos y metodos
//el document es un objeto
//Metodos son acciones ej geteementbyid
//Atributos son propiedades

//SESSION STORAGE

//Estableciendo el valor a guaradar en el sesion storage
//Primero le colocamos un nombre a lo que vamos a guardar Pruebasesionestorage despues le damos el valor acamica 2020
//sessionStorage.setItem("Pruebasesionestorage", "acamica 2020");


//LOCAL STORAGE

//Establecemsos la propiedad pruebaLocalStorage que guardará el valor  Hola
//localStorage.setItem("pruebaLocalStorage", "Hola");
//Obteniendo el valor de la propiedad pruebaLocalStorage  
//localStorage.getItem("pruebaLocalStorage");

///--------------------------------------------------------------

//Trayendo el select frutas
//let frutas = document.getElementById("frutas");
//Creando un elemento html vacio
//let uva = document.createElement("option");
//let manzana = document.createElement("option");


//uva.value = "Uva" // Asignando valor al atributo value 
//uva.text = "La uva" //colocandole texto al option
//manzana.text = "La manzana" //Colocandole texto al opcion manzana

//Asignando los option creados al elemento select frutas
// frutas.add(uva);
// frutas.add(manzana);






//----------------------------------------------------------------

//Guardando en variables todos los selects

let s1 = document.getElementById("s1");
let s2 = document.getElementById("s2");
let s3 = document.getElementById("s3");
let s4 = document.getElementById("s4");
let s5 = document.getElementById("s5");
let s6 = document.getElementById("s6");

let valores = "<option value='Alejandro'>Alejandro</option><option value='Dario'>Dario</option><option value='Tomas'>Tomas</option><option value='Benito'>Benito</option><option value='Andres'>Andres</option><option value='Carlos'>Carlos</option>";
//
valores = "<option value='valores'>Seleccione</option>" + valores

//En cada uno de los selects insertamos valores

s1.innerHTML = valores;
s2.innerHTML = valores;
s3.innerHTML = valores;
s4.innerHTML = valores;
s5.innerHTML = valores;
s6.innerHTML = valores;

//Cuando seleccioen un elemento de de cualquier select eliminelo de todos los selects

//es respuesta a un evento por eso lleva on
//Para saber a que elemento se le hizo click debemos pasar el id que viene desde el html
//El id correspondera a el select osea s1, s2, s3, s4, s5, s6
function on_select_change(element_id){
    // el id s1, s2, s3, s4, s5, s6 lo guardamos en la variable element
    let element = document.getElementById(element_id);
    // y la variable selected_value guarda el valor del atributo value que cambio
    //Es el value de los options  
    //obtiene el value del que cambie
     let selected_value = element.value;
     console.log(selected_value);

    //si hay un valor para s1 en el sesssion estorage
    sessionStorage.setItem(element_id, selected_value);
    //si el s1 esta guardado en el local storage entonces

    //Si la variable trae algo
    // if(var1) {

    // }

    //Si la variable no trae nada
    // if(!var){

    // }

}

//  si existe un valor para la llave s1
if(sessionStorage.getItem("s1") != null){
    // if(sessionStorage.getItem("s1"))
    let element = document.getElementById("s1");
    element.value = sessionStorage.getItem("s1")
}
if(sessionStorage.getItem("s2") != null){
    // if(sessionStorage.getItem("s1"))
    let element = document.getElementById("s2");
    element.value = sessionStorage.getItem("s2");
}

if(sessionStorage.getItem("s3") != null){
    // if(sessionStorage.getItem("s3"))
    let element = document.getElementById("s3");
    element.value = sessionStorage.getItem("s3");
}

if(sessionStorage.getItem("s4") != null){
    // if(sessionStorage.getItem("s4"))
    let element = document.getElementById("s4");
    element.value = sessionStorage.getItem("s4");
}

if(sessionStorage.getItem("s5") != null){
    // if(sessionStorage.getItem("s5"))
    let element = document.getElementById("s5");
    element.value = sessionStorage.getItem("s5");
}

if(sessionStorage.getItem("s6") != null){
    // if(sessionStorage.getItem("s6"))
    let element = document.getElementById("s6");
    element.value = sessionStorage.getItem("s6");
}








