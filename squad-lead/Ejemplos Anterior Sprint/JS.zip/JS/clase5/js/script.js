//comparadpres

/* <  > mayor y menor que 

<= >= menor o igual que mayor o igual que 

|| offscreenBuffering

&& y

=== igual en valor y tipo

== igual en valor

!== diferente en valor y tipo */


//comparando el valor

//true == 1 //true

//comparando el tipo de dato 

//true === 1 //false no son iguales en tipo

//true !== 1 //true porque los tipos de datos son diferentes




// Otras funcioens del navegador 

// confirm

// debuelve un true o un false

// console.log(confirm("Desea continuar"));



// Operador terniario

// var a = condicion ? "si true" : "si false";

// var x = 8;

// var y = x < 6 ? "si se cumple" : "No se cumple";

// console.log(y);


//Es como el if y el else

// console.log((confirm ("Desea continuar")) ? "Verdadero" : "falso");




// Verificando si un numero es par o impar 






// var number  = parseInt(prompt("Ingrese un numero"));
// console.log(typeof(number));

//Si resive una cadena de texto y no la puede convertir a number debuelve NaN
//IsNan debuelve true si no es un numero, y false si si es un numero

//Si es un número NaN (si no es un numero)
// if(!isNaN(number)){
//     var result = number % 2 === 0 ? "el numero es par": "El numero es impar";
//     console.log(result);
// }else{
//     console.log("Ingrese un número");
// }




// parseInt(prompt("Por favor ingrese su edad"));

// var confirm = confirm("Actualmente se encuentra cursando estudios");


// if(!isNaN(confirm)){
//     confirm == true ? alert("si esta estudiando") : alert("Estudie vago")
// }else{
//     alert("Ingrse un numero");
// }



// if(confirm){
//     alert("Si esta cursando estudios");
// }else{
//     alert("estudie vago");
// }


// var age_two = parseInt(prompt("por favor digite su edad"));

// if(!isNaN(age_two)){
//     age_two > 18 ? alert("Si puede votar") : alert("No puede votar");
// }else{
//     alert("ingrse un numero");
// }

// var user = prompt("Ingrese el usuario");

// var password = prompt("Ingrese la contraseña");

// var compare_password = "123456789";

// password == compare_password ? alert("Ingreso al sistema exitoso") : alert("No puede ingresar al sistema");



// number_one = parseInt(prompt("ingrse el primer numero"));

// number_two = parseInt(prompt("Ingrese el segundo número"));

// if(!isNaN(number_one) || !isNaN(number_two)){
//     number_two !== 0 ? alert("El resultado es" + number_one / number_two) : alert("No puede dividir por cero");
// }else {
//     alert("Por favor ingrese numeros");
// }



// var notes = parseInt(prompt("Ingrese su calificacion"));


// if(!isNaN(notes)){
    // notes >=  7 ? alert("Ha aprobado"): 
//     notes < 4 ? alert("Ha desaprobado"):
//     notes >= 4 && notes <= 6 ? alert("Tiene que recuperar"): alert("ha aprobado");
    
// }else{
//     alert("Por favor ingrse el valor en numeros")
// }



// var meeting_start = prompt("Ingrese la hora de inicio de la reunión");

// var metting_end = prompt("Ingrese la hora de finalización de la reunión");


// meeting_start >= metting_end ? alert("La hora es invalida") : alert("La informacion se guardo correctamenet");



var name = prompt("Ingrese su nombre");
var last_name = prompt("Ingrese su apellido");
var age = parseInt(prompt("Ingrese su edad"));

//sI ES UN NUMERO

// if(!isNaN(parseInt(name)) || !isNaN(parseInt(last_name)) || isNaN(age)){
//     alert("datos incorrectos");
// }else{
//     alert("Nombre: " + " " + name + "\n" + "Apellido: " + last_name + "\n" + "Edad: " + age );
// }



var fff = isNaN(name) ?  "" : alert("El nombre no puede ser un numero");
var ddd = isNaN(last_name) ? "" : alert("El apellido no puede ser un numero");
var tt = !isNaN(age) ? "" : alert("La edad no puede ser un string");









