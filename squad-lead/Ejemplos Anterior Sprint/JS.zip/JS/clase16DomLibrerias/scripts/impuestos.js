function iva(neto){
    var valor =  neto * 0.21;
    return valor;
}

