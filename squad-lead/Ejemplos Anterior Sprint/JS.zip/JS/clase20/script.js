const url = `https://api.chucknorris.io/jokes/random`;
let noticias = [];
console.log(noticias);
class chuckNoticia{
    constructor(icono, valor, url, fecha){
        this.icono = icono;
        this.valor = valor;
        this.url = url;
        this.fecha = fecha;
    }
    setfechaNoticia(){
        this.fecha = new Date(this.fecha);
    }
    getFechaNoticia(){
        return this.fecha;
    }
}
async function getNoticia(url) {
    let datos = await fetch(url);
    let respuesta = await datos.json();
    if (datos.ok) {
        // console.log("Respuesta OK");
        let {created_at: fecha, icon_url: icono, url, value: valor} = respuesta;
            const noticia = new chuckNoticia(icono, valor, url, fecha);
            noticias.push(noticia);
            noticia.setfechaNoticia();
    } else
        console.log("Algo falla con el link");

        return respuesta;

}


function open_modal(noticia){
    document.getElementById("staticBackdropLabel").innerHTML = noticia.id;
    $("#exampleModalCenter1").modal();


}



for(i=0; i<3; i++){
    getNoticia(url)
    .then((noticia)=>{
        console.log(noticia)
        
        var new_c = document.getElementById("news_card");

        var new_element = document.createElement("div");
        new_element.classList.add("text-center", "card");
        new_element.innerHTML = `
                    <div class="card-header" id="${noticia.id}">
                    Fecha Nota 1
                    </div>
                    <div class="card-body">
                    <h5 class="card-title">${noticia.id}</h5>
                    <img src="${noticia.icon_url}" alt="">
                    <button class="btn btn-primary" onclick="open_modal(${noticia})">Ver Nota</button>
                    </div>
                `

        new_c.appendChild(new_element);
    });
}




// for(news of noticias){
//     console.log(news[0]);
// }


