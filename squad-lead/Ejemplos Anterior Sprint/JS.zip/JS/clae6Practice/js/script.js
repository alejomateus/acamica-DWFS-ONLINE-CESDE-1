// ===============================================================


// Crear un script que permita ingresar solamente
// 5 valores mediante prompt y nos muestre la
// suma total de todos los valores ingresados

// var addition = 1


// do{
//     x = parseInt(prompt("Ingrese un número"));
//     addition = addition + x;

// }while(x < 5);

// alert("la suma de los cinco numeros es " + addition + " " + "El promedio es " + addition/5);




// ===============================================================


// Ingresar N cantidad de edades mediante prompt
// hasta que se ingrese un cero.
// Al finalizar mostrar cuántos son mayores de edad


// do {

//     x = parseInt(prompt("Ingrese la edad"));

// }while(x !== 0);




// ===============================================================



// Ingresar N cantidad de números mediante prompt.
// Mostrar el promedio de los números ingresados de un dígito.
// Terminar el programa con la palabra “salir”

var average = 0;

do{

    x = parseInt(prompt("Ingrese un número"));
    var number_length = x.length;

    if(number_length == 1){
      console.log(average = average + x); 
    }
   

}while(x !== "salir");







// usted puede comenzar ya 















