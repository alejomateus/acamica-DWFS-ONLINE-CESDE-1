
//Definiendo os arrays

// let my_array = []

// let my_array = new Array ()


// let data = [1, 2, 3, 100, true, false, "more"];



//Agregando elementos

//data.push('tacto'); //agrega elemento al final
//data.unshift('olfato'); //agrega elemento al inicio

//Buscando un elemento specifico mediante la funcion indexOf sabiendo el nombre del parametro 
//si no existe mostrará -1 existe si es diferente de -1
// let indice = data.indexOf("tacto");
// console.log(indice);


// data.shift(1);
// data.pop(100);



//otra forma de eliminar

// let borrar = data.indexOf(3)//capturamos el elemento 3 del array
// data.splice(borrar, 4); //borrara todo desde la posicion 4


// console.log(data.length);


// push y pop  el ultimo que llega es el ultimo de la FileReader
// con shift y unshift el ultimo elemento que llega se coloca de primero

// var array = [];



//============================================================================================

// Ingresar mediante prompt números indefinidamente hasta
// que el usuario ingrese “Stop”.
// Almacenar todos los datos en un array y mostrarlos al final.

// do {
//     var number = prompt("Ingrese un numero"); //paseInt
//     if(!isNaN(number)){
//         array.push(number);
//     }
    

// }while(number !==  "stop");

// console.log(array);





//============================================================================================

// Ingresar mediante prompt números hasta el ingreso de
// un 0
// Crear un array para los números pares, otro para los
// impares y un tercero para almacenar datos no numéricos.
// Mostrar los resultados al finalizar el ciclo.


// let pares = [];
// let impares = [];
// let letter = []

// do{
//     var number = parseInt(prompt("ingrese un numero"));
//     if(!isNaN(number) && number !== 0){
//         if(number % 2 == 0){
//             pares.push(number);
//         }else{
//             impares.push(number);
//         }
//     }else{
//         if(number !== 0){
//             letter.push(number);
//         }
//     }

// }while(number !== 0);

// console.log(pares);
// console.log(impares);
// console.log(letter);



//============================================================================================

// Ingresar mediante prompt números hasta el ingreso de
// un 0
// Almacenar la información en un array.
// Eliminar del array el número más alto y el más bajo

let number_list = [];

do  {

number = parseInt(prompt("Ingrese un numero"));

if(!isNaN(number) && number !== 0){
    number_list.push(number);
   
}

}while(number !== 0);


var large_number = Math.max(...number_list);
 
var delete_large_number = number_list.splice(number_list.indexOf(large_number),1);


var fewer_number = Math.min(...number_list);

var delete_fewer_number = number_list.splice(number_list.indexOf(fewer_number),1)




alert("El array final es " + number_list);
alert("el numero mayor eliminado es " + large_number + "  el numero menor eliminado es " + fewer_number);






























// var a = [1,2,3];
// var valmax = 0;

// for(i=0; i<a.length; i++){
//     if(a[i] > valmax){
//         valmax = a[i];
//     }
// }

