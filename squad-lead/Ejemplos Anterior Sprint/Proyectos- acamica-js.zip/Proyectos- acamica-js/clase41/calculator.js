const addition = (a,b) => a+b;
const subtraction = (a,b) => a-b;
const division = (a,b) => a/b;
const multiplication = (a,b) => a*b;

module.exports = {addition, subtraction, division, multiplication}