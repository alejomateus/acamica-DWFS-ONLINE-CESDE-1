function iva(neto) {
    return neto * 0.21;
}