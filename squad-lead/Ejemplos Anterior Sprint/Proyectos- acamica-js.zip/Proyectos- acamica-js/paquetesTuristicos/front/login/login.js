

// Toggle between Log In and Sign Up sections

let btnLogin = document.getElementById("btn-login");
let btnSignUp = document.getElementById("btn-signup");
let loginSection = document.querySelector(".login");
let signInSection = document.querySelector(".signIn");

btnLogin.addEventListener("click", () => {
    if (loginSection.classList.contains("hidden")) {
        loginSection.classList.remove("hidden");
        signInSection.classList.add("hidden");
    }
});

btnSignUp.addEventListener("click", () => {
    if (signInSection.classList.contains("hidden")) {
        signInSection.classList.remove("hidden");
        loginSection.classList.add("hidden");
    }
})


// ============ User Log In ========================

let formLogin = document.getElementById("form-login");
let userEmail = document.getElementById("email");
let userPassword = document.getElementById("password");

formLogin.addEventListener("submit", (e) => {
    e.preventDefault();
    let email = userEmail.value;
    let password = userPassword.value;
    logUser(email, password);
});

async function logUser(email, password) {
    let data = await fetch("http://localhost:5000/login", {

        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            correo: email,
            clave: password
        })
    });
    let response = await data.json();
    if (data.ok) {
        location.href = "../admin/index.html";
    } else if (data.status == 403) {
        console.error("Hmm, there´s someone already logged in")
    } else {
        console.log("Login failed, check your credentials!");
    }
}


// ================= User Sign Up =================

let signUp = document.getElementById("form-signup");
let userID = 1;

signUp.addEventListener("submit", (e) => {
    let firstName = document.getElementById("firstName");
    let lastName = document.getElementById("lastName");
    let emailSignup = document.getElementById("email-signup");
    let passwordSignup = document.getElementById("password-signup");

    e.preventDefault();

    let first_name = firstName.value;
    let last_name = lastName.value;
    let email = emailSignup.value;
    let password = passwordSignup.value;

    createUser(first_name, last_name, email, password);
});

function createUser(firstName, lastName, email, password) {
    if (firstName && lastName && email && password) {
        userID++;
        fetch("http://localhost:5000/signup", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                id: userID,
                nombre: firstName,
                apellido: lastName,
                correo: email,
                clave: password
            })
        })
            .then((data) => data.json())
            .then((res) => {
                console.log(res);
                if (data.ok) {
                    console.log("YES");
                }
            })
    }
}