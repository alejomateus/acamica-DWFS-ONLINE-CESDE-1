const table = document.getElementById('tabla-paquetes');

function peticionPaquetes() {

    fetch('http://127.0.0.1:5000/paquetes')
        .then((res) => {
            console.log(res);
            return res.json();
        })
        .then((data) => {
            console.log(data);
            if(!data.error){
                data.forEach(element => {
                    table.innerHTML += `
                        <tr>
                            <th>${element.id}</th>
                            <th>${element.origen}</th>
                            <th>${element.destino}</th>
                            <th>${element.descripcion}</th>
                            <th>$ ${element.precio}</th>
                            <th>
                                <a href="">Editar</a>
                                <a href="">Eliminar</a>            
                            </th>
                        </tr>
                    `
                });
            }
        });

}

peticionPaquetes();


function peticionCrearPaquete(){
    console.log(id);
}