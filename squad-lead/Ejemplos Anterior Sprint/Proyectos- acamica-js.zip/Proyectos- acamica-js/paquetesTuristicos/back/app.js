
const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const cors = require('cors');

app.use(bodyParser.urlencoded({
    extended: true
}));

app.use(bodyParser.json());
app.use(cors());
let logged = "";
// Datos
let usuarios = [
    {
        id: 1,
        nombre: 'Juan',
        apellido: 'Rojas',
        correo: 'juan@correo.com',
        clave: '1234567'
    }
];
let paquetes = [
    {
        id: 1,
        origen: 'Bogotá',
        destino: 'Cancún',
        descripcion: 'Boletos aereos via Avianca, 3 noches, 4 días, todo incluido',
        precio: 800000,
        vendido: false
    },
    {
        id: 2,
        origen: 'Bogotá',
        destino: 'Riviera Maya',
        descripcion: 'Boletos aereos via Avianca, 2 noches, 3 días, todo incluido',
        precio: 1000000,
        vendido: false
    }
]
// Usuario: Nombre, Apellido, correo, clave
// Paquete Turísitco: Destino, Orígen, descripción, precio
// Middleware para validar estado de sesión (logon o no)
function validarEstado(req, res, next) {
    if (logged != "") {
        res.status(403).json({ msg: "Forbidden" });
    } else {
        next();
    }
}
// Middleware para validar credenciales
function validarCredenciales(req, res, next) {
    const { correo, clave } = req.body;
    var index = usuarios.findIndex(el => el.correo == correo && el.clave == clave);
    req.params.findIndex = index;
    if (index == -1) {
        res.status(404).json({ error: "Clave o usuario incorrecta" });
    } else {
        next();
    }
}
function validarEmail(req, res, next) {
    const email = req.body.correo;
    const index = usuarios.findIndex(element => element.correo == email);
    if (index == -1) {
        next();
    } else {
        res.status(400).json({ error: "el email ya existe" });
    }
}
// Ruta Index
app.get("/usuarios", (req, res) => {
    res.json(usuarios);
})
// Ruta Login
app.post("/login", [validarEstado, validarCredenciales], (req, res) => {
    logged = req.body.correo;
    res.status(200).json({ msg: "Usuario correcto" });
});
// Ruta Signup
app.post("/signup", validarEmail, (req, res) => {
    usuarios.push(req.body);
    const { nombre, apellido } = req.body;
    res.status(200).json({ msg: `Usuario ${nombre} ${apellido} registrado exitosamente` })
});
//Ruta cerrar sesion
app.post('/logout', (req, res) => {
    logged = false;
    res.json({ msg: 'sesion cerrada correctamente' })
});
// Rutas Paquetes
function validarCreacionPaquete(req, res, next) {
    const id = req.body.id;
    var index = paquetes.findIndex(el => el.id == id);
    if (index == -1) {
        next();
    } else {
        res.status(404).json({ error: "ya existe un paquete con ese id" });
    }
}
function validarIdPaquete(req, res, next) {
    const id = req.params.id;
    var index = paquetes.findIndex(el => el.id == id);
    req.params.findIndex = index;
    if (index == -1) {
        res.status(404).json({ error: "el paquete no existe" });
    } else {
        next();
    }
}
app.get("/paquetes", (req, res) => {
    res.json(paquetes);
});
app.post("/paquetes", validarCreacionPaquete, (req, res) => {
    paquetes.push(req.body);
    res.status(200).json({ mensaje: 'Paquete creado correctamente' });
});
app.get("/paquetes/:id", validarIdPaquete, (req, res) => {
    const index = req.params.findIndex;
    res.json(paquetes[index]);
});
app.delete("/paquetes/:id", validarIdPaquete, (req, res) => {
    const index = req.params.findIndex;
    paquetes.splice(index, 1);
    res.json({ msg: "Paquete deleted" });
});

app.post('/paquetes/compra/:id', validarIdPaquete, (req, res) => {
    const index = req.params.findIndex;
    paquetes[index].vendido = true;
    res.json({msg:'paquete vendido'});
})
app.listen(5000, () => {
    console.log("Listening...");
})