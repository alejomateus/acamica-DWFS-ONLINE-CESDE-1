module.exports = {
    dwfs: [
        {
            name: 'pedro',
            lastname: 'perez'
        },
        {
            name: 'camilo',
            lastname: 'rojas'
        }
    ],

    dwa: [
        {
            name: 'pepe',
            lastname: 'perez'
        },
        {
            name: 'natalia',
            lastname: 'leon'
        }
    ],

    bigdata: [
        {
            name: 'camilo',
            lastname: 'ramirez'
        },
        {
            name: 'camilo',
            lastname: 'rojas'
        },
        {
            name: 'Johhny',
            lastname: 'martinez'
        }
    ]
}